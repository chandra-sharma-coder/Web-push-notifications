<p>
<?php

$i = 0;
while ($i <= 100){
    echo $i." ";
    $i++;
    usleep( 1000 );
}
?>
</p>

https://local.tt/videos/php-caching/demo/

https://github.com/hardik-choudhary/php-caching